﻿using System;
using System.Runtime.Serialization;

namespace CompareToolLogic
{
    [Serializable]
    public class InvalidConnectionstringException : Exception
    {
        public InvalidConnectionstringException()
        {
        }

        public InvalidConnectionstringException(string message) : base(message)
        {
        }

        public InvalidConnectionstringException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidConnectionstringException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}