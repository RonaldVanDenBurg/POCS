﻿using CompareToolLogic.Exceptions;
using CompareToolLogic.Models;
using CompareToolLogic.Models.Services;
using CompareToolLogic.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace CompareToolLogic
{
    class Program
    {

        static void Main(string[] args)
        {
            ISettingsModel SettingsModel = new SettingsModel();
            #region This code checks if userinput exists in databases.

            #region Create connectionstrings.
            IConnectionstringBuilder connectionA = new ConnectionstringBuilder($"localhost", "Subscribe", "sa", "WuTang317");
           // IConnectionstringBuilder connectionB = new ConnectionstringBuilder($"localhost", "Subscribe2", "sa", "WuTang317");
          //  IConnectionstringBuilder connectionC = new ConnectionstringBuilder($"localhost", "muziekdatabase", "sa", "WuTang317");
            #endregion

            #region Adds only valid connectionstrings to the ListOfConnections.
            IDatabaseSelectionModel databaseSelection = new DatabaseSelectionModel();

            databaseSelection.AddConnectionstringToList(connectionA);
           // databaseSelection.AddConnectionstringToList(connectionB);
          //  databaseSelection.AddConnectionstringToList(connectionC);
            #endregion


            Console.WriteLine($"The listOfConnections has {databaseSelection.ListOfConnections.Count()} elements.");
           // Console.WriteLine($"First onnectionstring:  {connectionB.Conn}");



            IFindInputService prefixservice = new PrefixService(databaseSelection.ListOfConnections);
            Console.WriteLine("============================================");
            Console.WriteLine(prefixservice.FindMatchToInput("TT_"));
            Console.WriteLine("============================================");

            IFindInputService wildcardService = new WildcardService(databaseSelection.ListOfConnections);
            Console.WriteLine("============================================");
            Console.WriteLine(wildcardService.FindMatchToInput("Descriptive"));
            Console.WriteLine("============================================");
            


            IFindInputService test = new Test(databaseSelection.ListOfConnections);
            Console.WriteLine("============================================");
            Console.WriteLine($"Found Repo?: {test.FindMatchToInput("")}") ;
            Console.WriteLine( test.IncludeExclude(SettingsModel.IncludeRepoIsChecked) ); 
            Console.WriteLine("============================================");
            #endregion

            Console.ReadLine();
        }


    }
}
