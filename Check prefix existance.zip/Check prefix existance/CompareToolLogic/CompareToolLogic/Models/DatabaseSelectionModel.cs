﻿using CompareToolLogic.Models;
using System.Collections.Generic;

namespace CompareToolLogic
{
    public class DatabaseSelectionModel : IDatabaseSelectionModel
    {

        public List<string> ListOfConnections { get; set; } = new List<string>();

        #region Add connectionstring to list.
        /// <summary>
        /// This method stores a ConnectionstringBuilder object (connectionstring) 
        /// into the ListOfConnections. Before the string is added to the list, 
        /// it will be validated. If it's valid, it will be added. 
        /// If not, an exception will be thrown.
        /// </summary>
        /// <param name="connectionstringBuilder"></param>
        /// <exception cref="InvalidConnectionstringException"></exception>
        public void AddConnectionstringToList(IConnectionstringBuilder connectionstringBuilder)
        {
            if (connectionstringBuilder.IsValidConnection(connectionstringBuilder.Conn))
            {
                ListOfConnections.Add(connectionstringBuilder.Conn);
            }
            else
            {
                throw new InvalidConnectionstringException("Can't add, connectionstring is invalid. Try again.");
            }
        }
        #endregion

    }
}

