﻿using System.Collections.Generic;

namespace CompareToolLogic.Models
{
    public interface ISettingsModel
    {
        bool ExcludePrefixIsChecked { get; set; }
        bool ExcludeRepoIsChecked { get; set; }
        bool ExcludeWildcardIsChecked { get; set; }
        bool IncludePrefixIsChecked { get; set; }
        bool IncludeRepoIsChecked { get; set; }
        bool IncludeWildcardIsChecked { get; set; }
        List<string> ListOfEntities { get; set; }
        List<string> ListOfPrefixes { get; set; }
        List<string> ListOfWildcards { get; set; }
        string SettingName { get; set; }
        bool StoredProceduresIsSelected { get; set; }
        bool TablesIsSelected { get; set; }
        bool TriggersIsSelected { get; set; }
        bool ViewsIsSelected { get; set; }
        string WildcardInput { get; set; }

        void AddToEntityToList(string entityInput);
        void ClearEntitiesList();
    }
}