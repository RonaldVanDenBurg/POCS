﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace CompareToolLogic.Models.Services
{
    public class Test : IFindInputService
    {
        private string _repository = "";

        public string FirstConnectionInListOfConnections { get; set; }
        
        public string Query { get; set; }

        public Test(List<string> ListOfConnections)
        {
            this.FirstConnectionInListOfConnections = ListOfConnections.ElementAt(0);
        }




        #region Check if Repo exists in database.
        /// <summary>
        /// This method takes a string of input. It adds it to a query to read data
        /// from a database to check if the input matches. If there is a match, 
        /// it returns True. If not, it returns False.
        /// </summary>
        /// <param name="_repository"></param>
        /// <returns></returns>
        public bool FindMatchToInput(string _repository)
        {
            _repository = "D_Name";
            this.Query = $"SELECT NAME FROM sysobjects WHERE NAME = N'{_repository}';";
            bool exist = false;

            #region Create connection en command.
            SqlConnection conn = new SqlConnection(FirstConnectionInListOfConnections);
            SqlCommand findMatchToInputQuery = new SqlCommand
            {
                Connection = conn,
                CommandText = Query
            };
            #endregion

            #region Read from connection.
            conn.Open();
            SqlDataReader reader = findMatchToInputQuery.ExecuteReader();
            while (reader.Read())
            {
                if (reader["NAME"].ToString().SequenceEqual(_repository))
                {
                    return true;
                }
            }
            reader.Close();
            conn.Close();
            #endregion

            return exist;
        }
        #endregion

        public string IncludeExclude(bool isChecked)
        {
            if (isChecked == true && FindMatchToInput(_repository) == true)
            {
                return "including repo";
            }
            else if (isChecked == true && !FindMatchToInput(_repository))
            {
                return "repo niet gevonden";
            }
            else
            {
                return "excluding repo";
            }
        }



    }
}
