﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace CompareToolLogic.Models.Services
{

    public class PrefixService : IFindInputService
    {
        public string FirstConnectionInListOfConnections { get; set; }
        public string Input { get; set; }
        public string Query { get; set; }


        public PrefixService(List<string> ListOfConnections)
        {
            this.FirstConnectionInListOfConnections = ListOfConnections.ElementAt(0);
        }


        #region Check if input exists in database.
        /// <summary>
        /// This method takes a string of input. It adds it to a query to read data
        /// from a database to check if the input matches. If there is a match, 
        /// it returns True. If not, it returns False.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public bool FindMatchToInput(string input)
        {
            this.Input = input;
            this.Query = $"SELECT NAME FROM sysobjects WHERE NAME LIKE N'{Input}%';";
            bool exist = false;

            #region Create connection en command.
            SqlConnection conn = new SqlConnection(FirstConnectionInListOfConnections);
            SqlCommand findMatchToInputQuery = new SqlCommand
            {
                Connection = conn,
                CommandText = Query
            };
            #endregion

            #region Read from connection.
            conn.Open();
            SqlDataReader reader = findMatchToInputQuery.ExecuteReader();
            while (reader.Read())
            {
                if (reader["NAME"].ToString().StartsWith(Input))
                {
                    return true;
                }
            }
            reader.Close();
            conn.Close();
            #endregion

            return exist;
        }
        #endregion

        public string IncludeExclude(bool isChecked)
        {
            if (isChecked == true && FindMatchToInput(Input) == true)
            {
                return "Including prefix";
            }
            else
            {
                return "Excluding prefix";
            }
        }
    }
}
