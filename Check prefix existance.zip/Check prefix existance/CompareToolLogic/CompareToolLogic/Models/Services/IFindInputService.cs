﻿namespace CompareToolLogic.Models.Services
{
    public interface IFindInputService
    {
        string FirstConnectionInListOfConnections { get; set; }
       // string Input { get; set; }
        string Query { get; set; }

        bool FindMatchToInput(string input);
        string IncludeExclude(bool isChecked);
    }
}