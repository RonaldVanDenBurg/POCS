﻿namespace CompareToolLogic.Models
{
    public interface IConnectionstringBuilder
    {
        string Conn { get; }
        string DatabaseName { get; set; }
        string Login { get; set; }
        string Password { get; set; }
        string Server { get; set; }

        bool IsValidConnection(string Conn);
    }
}