﻿namespace CompareToolLogic.Models
{
    public class PrefixModel
    {

        public string Prefix  { get; set; }

        public PrefixModel()
        {

        }

        public PrefixModel(string input)
        {
            this.Prefix = input;
        }

       
    }
}
