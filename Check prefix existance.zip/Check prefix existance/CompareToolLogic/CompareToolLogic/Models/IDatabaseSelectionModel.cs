﻿using CompareToolLogic.Models;
using System.Collections.Generic;

namespace CompareToolLogic
{
    public interface IDatabaseSelectionModel
    {
        List<string> ListOfConnections { get; set; }

        void AddConnectionstringToList(IConnectionstringBuilder connectionstringBuilder);
    }
}