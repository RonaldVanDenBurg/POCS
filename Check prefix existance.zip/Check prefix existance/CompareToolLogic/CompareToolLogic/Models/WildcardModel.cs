﻿namespace CompareToolLogic.Models
{
    public class WildcardModel
    {
        public string Wildcard { get; set; }

        public WildcardModel()
        {

        }

        public WildcardModel(string input)
        {
            this.Wildcard = input;
        }
    }
}
