﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareToolLogic.Models
{
    public class SettingsModel : ISettingsModel
    {

        // Entity selection.
        public bool TablesIsSelected { get; set; } = false;
        public bool StoredProceduresIsSelected { get; set; } = false;
        public bool ViewsIsSelected { get; set; } = false;
        public bool TriggersIsSelected { get; set; } = false;



        // Settings selection
        public List<string> ListOfEntities { get; set; } = new List<string>();
        public List<string> ListOfPrefixes { get; set; } = new List<string>();
        public List<string> ListOfWildcards { get; set; } = new List<string>();

        public bool IncludeRepoIsChecked { get; set; }
        public bool ExcludeRepoIsChecked { get; set; }
        public bool IncludePrefixIsChecked { get; set; }
        public bool ExcludePrefixIsChecked { get; set; }
        public bool IncludeWildcardIsChecked { get; set; }
        public bool ExcludeWildcardIsChecked { get; set; }

        public string SettingName { get; set; }
        public string WildcardInput { get; set; }


        public SettingsModel()
        {

        }




        public void AddToEntityToList(string entityInput)
        {
            ListOfEntities.Add(entityInput);
        }
        public void ClearEntitiesList()
        {
            ListOfEntities.Clear();
        }
    }
}
