﻿using CompareToolLogic.Exceptions;
using CompareToolLogic.Models;
using CompareToolLogic.Models.Services;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace CompareToolLogic
{
    class Program
    {

        static void Main(string[] args)
        {

            #region This code populates the ResultList with lists of DatabaseObjects using services.


            #region Create connectionstrings.
            //ConnectionstringBuilder connectionA = new ConnectionstringBuilder($"localhost", "Subscribe", "sa", "WuTang317");
            ConnectionstringBuilder connectionB = new ConnectionstringBuilder($"localhost", "Subscribe", "sa", "WuTang317");
            ConnectionstringBuilder connectionC = new ConnectionstringBuilder($"localhost", "muziekdatabase", "sa", "WuTang317");

            Console.WriteLine($"This is the connectionstring: {connectionC.Conn}");
            Console.WriteLine($"Is connectionstring valid? {connectionC.IsValidConnection(connectionC.Conn)}");
            #endregion

            #region Add connectionstrings to the ListOfConnections.
            /*            
            Add connectionstring to list.
            Only valid connectionstrings will be added.
            */
            DatabaseSelectionModel databaseSelection = new DatabaseSelectionModel();

            //databaseSelection.AddConnectionstringToList(connectionA);
            databaseSelection.AddConnectionstringToList(connectionB);
            databaseSelection.AddConnectionstringToList(connectionC);
            #endregion

            #region Add services to listOfServices.
            // Add services to list. These are added when the entity checkboxes
            // are checked in the frontend.
            List<IService> listOfServices = new List<IService>
            {
                new TableService(),
                new ProcedureService(),
                new TriggerService(),
                new ViewService()
            };
            #endregion

            #region Add the query strings of all IService objects to the listOfQueries.  
            List<string> listOfQueries = new List<string>();
            foreach (IService service in listOfServices)
            {
                listOfQueries.Add(service.Query.ToString());
            }
            #endregion

            #region Create one select statement based on the selected services.
            /*
             * This piece of code turns all the queries from the selected
             * services into one queryString. It adds a UNION at the end of each 
             * service query, except for the last query. By doing so, it is possible
             * to create one large select statement that returns one list with all the
             * results. It first checks if the listOfQueries is empty or not. 
             * If there is only query in the list, then no UNION is needed. 
             * Then it adds UNION to all queries except for the last query. 
             * And finally the queryString is stored in the fullquery string 
             * and ORDER BY TYPE is added.
             * Then the fullquery is written to the console.
            */

            string queryString = "";

            for (int i = 0; i < listOfQueries.Count; i++)
            {

                if (listOfQueries.Count != 0)
                {
                    if (listOfQueries.Count == 1)
                    {
                        queryString += listOfQueries.ToString();
                    }
                    if (listOfQueries.Count > 1)
                    {
                        if (i == listOfQueries.Count - 1)
                        {
                            queryString += listOfQueries[i].ToString();
                        }
                        else
                        {
                            queryString += listOfQueries[i].ToString() + " UNION ";
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Empty list");
                }
            }
            
            string fullQuery = queryString.ToString() + "ORDER BY TYPE";
            Console.WriteLine($"This is the full query: \n{fullQuery}");
            Console.WriteLine();
            #endregion

            #region Retrieve data from a database (connectionstring) and store it in a list of lists.
            /*
             * This piece of code uses the connectionstrings from the ListOfConnections. It 
             * opens the connection, runs the fullquery to access the databaseObjects and 
             * stores them in the listOfDatabaseObjects. When all the databaseObjects are 
             * retrieved from the connection, it closes the connection. Then it stores the 
             * listOfDatabaseObjects in the resultList. So every list in the resultList is
             * a database.
             */

            List<DatabaseObjectModel> listOfDatabaseObjects;
            List<List<DatabaseObjectModel>> resultListOfSelection = new List<List<DatabaseObjectModel>>();
            DatabaseObjectModel databaseObject;

            foreach (string connectionstring in databaseSelection.ListOfConnections)
            {
                listOfDatabaseObjects = new List<DatabaseObjectModel>();
                SqlConnection conn = new SqlConnection(connectionstring);
                SqlCommand selectObjects = new SqlCommand
                {
                    Connection = conn,
                    CommandText = fullQuery
                };

                try
                {
                    conn.Open();

                    SqlDataReader reader = selectObjects.ExecuteReader();

                    while (reader.Read())
                    {
                        databaseObject              = new DatabaseObjectModel();
                        databaseObject.Name         = reader["name"].ToString();
                        databaseObject.ObjectType   = reader["type"].ToString();
                        databaseObject.Definition   = "Definition placeholder";
                        databaseObject.Parameter    = "Parameter placeholder";
                        databaseObject.Metadata     = "Metadata placeholder";
                        databaseObject.Content      = "Content placeholder";

                        listOfDatabaseObjects.Add(databaseObject);
                    }
                    reader.Close();
                    conn.Close();

                    resultListOfSelection.Add(listOfDatabaseObjects);
                }

                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            // Check if lists are added.
            Console.WriteLine($"Amount of databases in ResultList: {resultListOfSelection.Count} \n");
            #endregion

            #region Read ResultsList.
            // Read ResultsList that contains lists of databaseObjects for double check.
            foreach (List<DatabaseObjectModel> listOfDBObjects in resultListOfSelection)
            {
                if (listOfDBObjects.Count != 0)
                {
                    Console.WriteLine($"Ämount of objects in list: {listOfDBObjects.Count}");
                    foreach (DatabaseObjectModel obj in listOfDBObjects)
                    {
                        Console.WriteLine($"Object name: {obj.Name}");
                        Console.WriteLine($"Object Type: {obj.ObjectType}");
                        Console.WriteLine($"Object Definition: {obj.Definition}");
                        // Console.WriteLine($"Object Parameters: {obj.Parameter}");
                        //Console.WriteLine($"Object Metadata: {obj.Metadata}");
                        Console.WriteLine("-------------------------------------");
                    }
                    Console.WriteLine("================ NEXT DATABASE ==================");
                }
                else
                {
                    Console.WriteLine("List is empty. It has no objects.");
                }
            }
            #endregion

            #region Add List at index 0 of the resultlist to the compareList. 
            List<List<DatabaseObjectModel>> compareList = new List<List<DatabaseObjectModel>>();

            if (resultListOfSelection.Count != 0)
            {
                compareList.Add(resultListOfSelection.ElementAt(0));
            }
            else
            {
                Console.WriteLine("Resultlist is empty.");
            }

            Console.WriteLine($"\nThe ComparList has {compareList.Count} lists.\n");
            #endregion

            #region Read comparelist.
            Console.WriteLine("Lets read out the compare list....");
            foreach (List<DatabaseObjectModel> list in compareList)
            {
                foreach (DatabaseObjectModel obj in list)
                {
                    Console.WriteLine(obj.Name);
                    Console.WriteLine(obj.ObjectType);
                }
            }
            #endregion

            #region Add services to iServiceList.
            List<IService> iServiceList = new List<IService>();
            bool TableSelected = true;
            bool ProcedureSelected = true;
            bool TriggerSelected = true;
            bool ViewSelected = true;


            AddServicesToList(iServiceList, TableSelected, ProcedureSelected, TriggerSelected, ViewSelected);

            Console.WriteLine(iServiceList.Count);
                foreach (IService service in iServiceList)
                {
                    Console.WriteLine(service);

                }
            #endregion
            
            Console.ReadLine();
            #endregion
        }



        private static void AddServicesToList(List<IService> iServiceList, bool TableSelected, bool ProcedureSelected, bool TriggerSelected, bool ViewSelected)
            {
                if (TableSelected)
                {
                    iServiceList.Add(new TableService());
                }
                if (ProcedureSelected)
                {
                    iServiceList.Add(new ProcedureService());
                }
                if (TriggerSelected)
                {
                    iServiceList.Add(new TriggerService());
                }
                if (ViewSelected)
                {
                    iServiceList.Add(new ViewService());
                }
                else
                {
                    throw new NoEntitiesSelectedException();
                }
            }

    }
}
