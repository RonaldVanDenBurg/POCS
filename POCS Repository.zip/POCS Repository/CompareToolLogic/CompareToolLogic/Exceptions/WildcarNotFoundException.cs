﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareToolLogic.Exceptions
{
    internal class WildcarNotFoundException : Exception
    {
        public WildcarNotFoundException()
        {

        }
        public WildcarNotFoundException(string message) : base(message)
        {

        }
        public WildcarNotFoundException(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
