﻿using System;

namespace CompareToolLogic.Exceptions
{
    public class PrefixNotFoundException : Exception
    {
        public PrefixNotFoundException()
        {

        }
        public PrefixNotFoundException(string message) : base(message)
        {

        }
        public PrefixNotFoundException(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
