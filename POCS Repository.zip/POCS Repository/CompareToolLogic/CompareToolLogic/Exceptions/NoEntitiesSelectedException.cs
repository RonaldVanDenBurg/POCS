﻿using System;
using System.Runtime.Serialization;

namespace CompareToolLogic.Exceptions
{
    [Serializable]
    public class NoEntitiesSelectedException : Exception
    {

        public NoEntitiesSelectedException()
        {

        }

        public NoEntitiesSelectedException(string message) : base(message)
        {

        }

        public NoEntitiesSelectedException(string message, Exception innerException) : base(message, innerException)
        {

        }

        public NoEntitiesSelectedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {

        }
    }
}
