﻿using System.Collections.Generic;

namespace CompareToolLogic.Models
{
    public class ResultModel
    {

        public List<List<DatabaseObjectModel>> ResultList { get;  } = new List<List<DatabaseObjectModel>>();
        //public List<DatabaseObjectModel> ListOfDatabaseObjects { get; set; }

        public ResultModel()
        {

        }


        public void AddToResultList(List<DatabaseObjectModel> listOfDatabaseObjects)
        {
            ResultList.Add(listOfDatabaseObjects);
        }
    }
}
