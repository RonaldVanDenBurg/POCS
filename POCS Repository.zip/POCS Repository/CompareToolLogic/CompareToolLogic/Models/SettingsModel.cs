﻿using System.Collections.Generic;

namespace CompareToolLogic.Models
{
    public class SettingsModel
    {
        // Entity selection.
        public bool TablesIsSelected { get; set; } = false;
        public bool StoredProceduresIsSelected { get; set; } = false;
        public bool ViewsIsSelected { get; set; } = false;
        public bool TriggersIsSelected { get; set; } = false;



        // Settings selection
        public string SettingName { get; set; }
        public string WildcardInput { get; set; }
        public List<string> ListOfEntities { get; set; } = new List<string>();
        public List<string> ListOfPrefixes { get; set; } = new List<string>();
        public List<string> ListOfWildcards { get; set; } = new List<string>();
        public bool IncludeRepo { get; set; } = false;
        public bool IncludePrefix { get; set; } = false;
        public bool IncludeWildcard { get; set; } = false;


        public SettingsModel()
        {

        }


        public void AddToEntityToList(string entityInput)
        {
            ListOfEntities.Add(entityInput);
        }
        public void ClearEntitiesList()
        {
            ListOfEntities.Clear();
        }




    }
}