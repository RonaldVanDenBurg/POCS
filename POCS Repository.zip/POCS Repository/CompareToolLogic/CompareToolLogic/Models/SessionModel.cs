﻿namespace CompareToolLogic.Models
{
    public class SessionModel
    {
        public SettingsModel SettingsModel { get; set; }
        
    }
}
