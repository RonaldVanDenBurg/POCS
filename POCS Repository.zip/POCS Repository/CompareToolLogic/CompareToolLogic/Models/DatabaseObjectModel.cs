﻿using System;
using System.Collections.Generic;

namespace CompareToolLogic.Models
{
    public class DatabaseObjectModel
    {
        public string Name { get; set; }
        public string ObjectType { get; set; }
        public string Definition { get; set; }
        public string Parameter { get; set; }
       // public List<ParameterModel> ListOfParameters { get; set; } = new List<ParameterModel>();
        public string Metadata { get; set; }
        public string Content { get; set; }
               
        public DatabaseObjectModel()
        { }

        public DatabaseObjectModel(string name, string objectType, string definition, string parameter, string metadata, string content)
        {
            this.Name = name;
            this.ObjectType = objectType;
            this.Definition = definition;
            this.Parameter = parameter;
           // this.ListOfParameters = listOfParameters;
            this.Metadata = metadata;   
            this.Content = content;
        }


        public void AddParametersToList(ParameterModel parameter)
        { 
           // ListOfParameters.Add(parameter);
        }


        #region
        /// <summary>
        /// This method reads the list of Parameters.
        /// </summary>
        /// <param name="ListOfParameters"></param>
        /// <returns></returns>
        public bool ReadListOfParameters(List<ParameterModel> ListOfParameters)
        {
            if (ListOfParameters != null)
            {
                foreach (ParameterModel parameter in ListOfParameters)
                {
                    Console.WriteLine(parameter.MyParameter);
                }
                return true;
            }
            else
            {
                Console.WriteLine("List is null.");
                return false;
            }
        }
        #endregion
    }
}
