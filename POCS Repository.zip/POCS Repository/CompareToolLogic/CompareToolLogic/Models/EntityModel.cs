﻿namespace CompareToolLogic.Models
{
    public class EntityModel
    {
        public string EntityName { get; set; }
        public string EntityType { get; set; }
    }
}
