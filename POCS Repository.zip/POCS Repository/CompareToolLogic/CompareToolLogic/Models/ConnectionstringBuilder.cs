﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareToolLogic.Models
{
    public class ConnectionstringBuilder
    {
      
        public string Server { get; set; }
        public string DatabaseName { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Conn { get; }
       

    /*    public ConnectionstringBuilder()
        {

        }*/

        public ConnectionstringBuilder(string server, string databaseName, string login, string password)
        {
            Server = server;
            DatabaseName = databaseName;
            Login = login;
            Password = password;
            Conn = $"Data Source={server};Initial Catalog={databaseName};User ID={login};Password={password};";
        }

        #region Validate the connectionstring.
        /// <summary>
        /// This method checks if the connectionstring is valid.
        /// </summary>
        /// <param name="Conn"></param>
        /// <returns></returns>
        public bool IsValidConnection(string Conn)
        {
            try
            {
                using (SqlConnection ValidatedConnectionString = new SqlConnection(Conn))
                {
                    ValidatedConnectionString.Open();
                    ValidatedConnectionString.Close();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
        #endregion



    }
}
