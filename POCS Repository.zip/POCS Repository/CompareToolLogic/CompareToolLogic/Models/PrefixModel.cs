﻿namespace CompareToolLogic.Models
{
    public class PrefixModel
    {

        public string Prefix  { get; set; }

        public PrefixModel(string prefix)
        {
            this.Prefix = prefix;
        }

       
    }
}
