﻿namespace CompareToolLogic.Models.Services
{
    public class ViewService : IService
    {
        public string Query
        {
            get
            {
                return "SELECT NAME, TYPE FROM sysobjects WHERE xtype = N'V'";
            }
        }
    }
}
