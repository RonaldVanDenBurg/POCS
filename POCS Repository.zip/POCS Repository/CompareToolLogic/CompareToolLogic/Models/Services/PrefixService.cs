﻿using CompareToolLogic.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareToolLogic.Models.Services
{
    
    // This class implements the IService interface.
    // It receives a string as input (prefix) and adds it to a query.
    // The query retrieves the amount of times the given input
    // occurs in the database.
    // If the count is 0, it doesn't exist.

    public class PrefixService : IService
    {
        public string Prefix { get; set; }
        public string Query { get; set; }

        public PrefixService()
        {

        }

        public PrefixService(string prefix)
        {
            this.Prefix = prefix;
            this.Query = $"SELECT COUNT(*) AS Result FROM sysobjects WHERE NAME LIKE N'{Prefix}%';";
        }
    }
}
