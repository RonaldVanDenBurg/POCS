﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareToolLogic.Models.Services
{
    public class WildcardService : IService
    {

        public string InputWildcard { get; set; }
        public string Query { get; set; }

        public WildcardService()
        {

        }

        public WildcardService(string inputWildcard)
        {
            this.InputWildcard = inputWildcard;
            this.Query = $"SELECT COUNT(*) AS Result FROM sysobjects WHERE NAME = N'{InputWildcard}';";
        }
    }
    }
