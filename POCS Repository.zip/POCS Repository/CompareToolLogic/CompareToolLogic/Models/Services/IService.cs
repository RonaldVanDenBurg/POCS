﻿namespace CompareToolLogic.Models.Services
{
    public interface IService
    {        
        string Query { get; }
    }
}