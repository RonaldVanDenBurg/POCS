﻿namespace CompareToolLogic.Models.Services
{
    internal class TriggerService : IService
    {
        public string Query
        {
            get
            {
                return "SELECT NAME, TYPE FROM sysobjects WHERE xtype = N'TR'";
            }
        }
    }
}
