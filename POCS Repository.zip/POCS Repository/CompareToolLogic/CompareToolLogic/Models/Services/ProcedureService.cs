﻿namespace CompareToolLogic.Models.Services
{
    public class ProcedureService : IService
    {
        public string Query
        {
            get
            {
                return "SELECT NAME, TYPE FROM sysobjects WHERE xtype = N'P'"; 
            }
            
        }
    }
}
