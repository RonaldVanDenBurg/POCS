﻿namespace CompareToolLogic.Models.Services
{
    public class TableService : IService
    {
        public string Query 
        { 
            get
            {
                return "SELECT NAME, TYPE FROM sysobjects WHERE xtype = N'U' AND NAME NOT LIKE N'sys%'";
            }
        }
    }
}
