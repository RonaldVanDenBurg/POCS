﻿namespace CompareToolLogic.Models
{
    public class ParameterModel
    {
        public string MyParameter { get; set; }

        public ParameterModel(string myParameter)
        {
            MyParameter = myParameter;
        }
    }
}
