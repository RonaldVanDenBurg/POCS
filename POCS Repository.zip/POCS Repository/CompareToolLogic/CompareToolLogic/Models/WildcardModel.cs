﻿namespace CompareToolLogic.Models
{
    public class WildcardModel
    {
        public string Wildcard { get; set; }
    }
}
