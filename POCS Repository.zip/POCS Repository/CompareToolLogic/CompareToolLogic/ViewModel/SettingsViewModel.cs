﻿using CompareToolLogic.Exceptions;
using CompareToolLogic.Models;
using CompareToolLogic.Models.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CompareToolLogic.ViewModel
{
    public class SettingsViewModel : BaseViewModel
    {
        public IServiceProvider PrefixService { get; }
        public SettingsModel SettingsModel { get; set; }
        public DatabaseSelectionModel DatabaseSelectionModel { get; set; }
        public DatabaseSelectionModel SelectionModel { get; set; }
        private ObservableCollection<IService> ListOfServices { get; set; } = new ObservableCollection<IService>();
        private ObservableCollection<string> ListOfPrefixes { get; set; } = new ObservableCollection<string>();
        private ObservableCollection<string> ListOfWildcards { get; set; } = new ObservableCollection<string>();
        public ICommand HelpCommand { get; }

        // If a class has a list of objects, allways inintialize it in the class as an empty list.
        // To avoid NullReferenceExceptions.
        public SettingsViewModel()
        {
           
        }


        // Entity selection.
        private bool _tablesIsSelected = false;
        public bool TablesIsSelected
        {
            get { return _tablesIsSelected; }
            set { _tablesIsSelected = value; OnPropertyChanged("TablesIsSelected"); }
        }

        private bool _storedProceduresIsSelected = false;
        public bool StoredProceduresIsSelected
        {
            get { return _storedProceduresIsSelected; }
            set { _storedProceduresIsSelected = value; OnPropertyChanged("StoredProceduresIsSelected"); }
        }

        private bool _viewsIsSelected = false;
        public bool ViewsIsSelected
        {
            get { return _viewsIsSelected; }
            set { _viewsIsSelected = value; OnPropertyChanged("ViewsIsSelected"); }
        }

        private bool _triggersIsSelected = false;
        public bool TriggersIsSelected
        {
            get { return _triggersIsSelected; }
            set { _triggersIsSelected = value; OnPropertyChanged("TriggersIsSelected"); }
        }


        // Settings selection.
        private bool _chkbIncludeRepoIsSelected = false;
        public bool ChkbIncludeRepoIsSelected
        {
            get { return _chkbIncludeRepoIsSelected; }
            set { _chkbIncludeRepoIsSelected = value; OnPropertyChanged("ChkbIncludeRepoIsSelected"); }
        }

        private string _prefixInput;
        public string PrefixInput
        {
            get { return _prefixInput; }
            set { _prefixInput = value; OnPropertyChanged("PrefixInput"); }
        }

        private bool _chkbIncludePrefixIsSelected = false;
        public bool ChkbIncludePrefixIsSelected
        {
            get { return _chkbIncludePrefixIsSelected; }
            set { _chkbIncludePrefixIsSelected = value; OnPropertyChanged("ChkbIncludePrefixIsSelected"); }
        }

        private string _wildcardInput;
        public string WildcardInput
        {
            get { return _wildcardInput; }
            set { _wildcardInput = value; OnPropertyChanged("WildcardInput"); }
        }

        #region Add wildcard to list.
        /// <summary>
        /// This method adds a wildcard to the listOfWildcards only 
        /// if the given wildcard occurs in the database at index 0.
        /// </summary>
        /// <exception cref="PrefixNotFoundException"></exception>
        public void AddPrefixToList()
         {
             if (PrefixExists(_prefixInput))
             {
                 ListOfPrefixes.Add(_prefixInput);
             }
             else
             {
                 throw new PrefixNotFoundException("Prefix does not exist in the database.");
             }
         }
        #endregion

        #region Add wildcard to list.
        /// <summary>
        /// This method adds a wildcard to the listOfWildcards only 
        /// if the given wildcard occurs in the database at index 0.
        /// </summary>
        /// <exception cref="WildcarNotFoundException"></exception>
        public void AddWildCardToList()
        {
            if (WildcardExists(_wildcardInput))
            {
                ListOfWildcards.Add(_wildcardInput);
            }
            else
            {
                throw new WildcarNotFoundException("Wildcard does not exist in the database.");
            }
        }
        #endregion

        #region Check if prefix exists.
        /// <summary>
        /// This method checks if the prefix the user typed in
        /// exists in the database at index 0.
        /// </summary>
        /// <param name="prefixInput"></param>
        /// <returns></returns>

        public bool PrefixExists(string prefixInput)
        {
            #region Create connection and command.
            IService prefixService = new PrefixService(prefixInput);
            
                    string firstConnectionStringInList = SelectionModel.ListOfConnections.ElementAt(0);
                    SqlConnection conn = new SqlConnection(firstConnectionStringInList);
                    SqlCommand searchPrefix = new SqlCommand
                        {
                            Connection = conn,
                            CommandText = prefixService.Query
                        };
           
            Int32 count = (Int32)searchPrefix.ExecuteScalar();
            #endregion

                // Run command to check if the input exists in the database at index 0.
                if (count > 0)
                {
                    conn.Open();
                    SqlDataReader reader = searchPrefix.ExecuteReader();
                    reader.Read();
                    reader.Close();
                    conn.Close();
                    
                    return true;
                }
                else
                {
                    return false; 
                }
        }
        #endregion

        #region Check if Wildcard exists.
        /// <summary>
        /// This method checks if the wildcard the user typed in
        /// exists in the database at index 0.
        /// </summary>
        /// <param name="prefixInput"></param>
        /// <returns></returns>

        public bool WildcardExists(string _wildcardInput)
        {
            #region Create connection and command.
            IService prefixService = new PrefixService(_wildcardInput);

            string firstConnectionStringInList = SelectionModel.ListOfConnections.ElementAt(0);
            SqlConnection conn = new SqlConnection(firstConnectionStringInList);
            SqlCommand searchPrefix = new SqlCommand
            {
                Connection = conn,
                CommandText = prefixService.Query
            };

            Int32 count = (Int32)searchPrefix.ExecuteScalar();
            #endregion

            // Run command to check if the input exists in the database at index 0.
            if (count > 0)
            {
                conn.Open();
                SqlDataReader reader = searchPrefix.ExecuteReader();
                reader.Read();
                reader.Close();
                conn.Close();

                return true;
            }

            else
            {
                return false;
            }
        }
        #endregion

        #region chkBox_Wildcard
        private bool _chkBIncludeWildCardIsSelected = false;
        public bool ChkBIncludeWildCardIsSelected
        {
            get { return _chkBIncludeWildCardIsSelected; }
            set { _chkBIncludeWildCardIsSelected = value; OnPropertyChanged("ChkBIncludeWildCardIsSelected"); }
        }
        #endregion

        #region Setting name.
        private string _settingName;
        public string SettingName
        {
            get { return _settingName; }
            set { _settingName = value; OnPropertyChanged("SettingName"); }
        }
        #endregion

        public void AddServicesToList()
        {

        }



}





    // Write a method (PrefixExists) that takes a prefix and checks if the prefix exist.
    // This method should be triggered by the use of a comma beacuse the string of prefixes wil be a CSV string (Comma Seperated Values).
    // The method needs to take the connectionstring from the database on index 0 from the ListOfConnections.
    // The method needs to open the connectionstring and search de database for the prefix.
    // If the prefix is found the method should return "true"
    // If the prefix is not found the method should return "false".
    /*
     
    public bool DoesPrefixExists(string enteredPrefix)
    {
    // Open connectionstring at index 0 of the listOfConnections.
    // Run the storedprocedure to get the names from all the objects.
    // Store them in a list (ListOfNames).
    // Close the connection.
    // Then iterate through the list to see if there is a match between objects in the list and the 'enteredPrefix'.

        foreach (string s in ListOfNames)
        {
            if (s.StartsWith(enteredPrefix))
            {
                SettingsModel.PrefixList.Add(enteredPrefix);
                return true;
            }
            else
            {
                return false;
            }
        }
    }*/



    /*
            public void AddPrefixToList(string enteredPrefix)
            {
                // Todo check if prefix exists in database.
                // If the prefix exists in database, add prefix to list.
                // If prefix doesn't exist, don't add to list and show message "Prefix doesn't exist."
                try 
                {
                    if (DoesPrefixExists())
                    {
                        SettingsModel.PrefixList.Add(enteredPrefix);
                    }
                }
                catch(PrefixNotFoundException)
                {
                    // Todo
                    // Write a custom exception prefixNotFoundException.
                    throw new PrefixNotFoundException("Prefix does not exist. Try again.");         
                }

            }





            public bool AddWildcardToList(string enteredWildcard)
            {
                // Todo check if wildcard exists with the method 'PrefixExists'.
                // If the wildcard exists in database, add wildcard to list.
                // If wildcard doesn't exist, don't add to list and show message "Wildcard doesn't exist."
                if (enteredWildcard == "")
                {
                    SettingsModel.PrefixList.Add(enteredWildcard);
                    return true;
                }
                else
                {
                    // Todo
                    throw new WildcardNotFoundException("Wildcard does not exist. Try again.");
                    return false;
                }

            }



    */

}
